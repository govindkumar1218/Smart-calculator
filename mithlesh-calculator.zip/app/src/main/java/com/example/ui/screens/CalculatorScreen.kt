package com.example.ui.screens

import java.text.DecimalFormat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ActionRed
import com.example.ui.theme.FnBlue
import com.example.ui.theme.NumButtonDark
import com.example.ui.theme.NumButtonLight
import com.example.ui.theme.OperatorOrange
import com.example.viewmodel.CalculatorViewModel

@Composable
fun CalculatorScreen(viewModel: CalculatorViewModel) {
    val input by viewModel.calcInput.collectAsState()
    val result by viewModel.calcResult.collectAsState()
    val isRad by viewModel.isRadians.collectAsState()
    val memory by viewModel.memory.collectAsState()
    val themeMode by viewModel.theme.collectAsState()
    val fontSizeMode by viewModel.fontSize.collectAsState()

    var showScientific by remember { mutableStateOf(false) }
    val clipboardManager = LocalClipboardManager.current

    val isDark = when (themeMode) {
        "light" -> false
        "dark" -> true
        else -> true // default dark theme for calculator
    }

    // Adapt font sizes based on settings
    val displayInputSize = when (fontSizeMode) {
        "small" -> 28.sp
        "large" -> 44.sp
        else -> 36.sp
    }
    val displayResultSize = when (fontSizeMode) {
        "small" -> 36.sp
        "large" -> 60.sp
        else -> 48.sp
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // --- DISPLAY PANEL ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.2f)
                .padding(bottom = 12.dp)
                .clickable {
                    if (result.isNotEmpty() && result != "Error") {
                        clipboardManager.setText(AnnotatedString(result))
                        viewModel.vibrate()
                    }
                },
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isDark) Color(0xFF161A22) else Color(0xFFECEFF1)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.End
            ) {
                // Top controls inside display
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Radians / Degrees indicator
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isRad) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.2f))
                            .clickable { viewModel.toggleRadians() }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isRad) "RAD" else "DEG",
                            color = if (isRad) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Memory status label
                    if (memory != 0.0) {
                        Text(
                            text = "M = ${DecimalFormat("#.##").format(memory)}",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }

                    // Toggle scientific layout
                    IconButton(
                        onClick = {
                            showScientific = !showScientific
                            viewModel.vibrate()
                        },
                        modifier = Modifier.size(36.dp).testTag("scientific_toggle")
                    ) {
                        Icon(
                            imageVector = if (showScientific) Icons.Default.Calculate else Icons.Default.Science,
                            contentDescription = "Toggle Scientific Layout",
                            tint = if (showScientific) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Math Input expression
                Text(
                    text = input.ifEmpty { "0" },
                    style = MaterialTheme.typography.displaySmall.copy(
                        fontSize = displayInputSize,
                        fontWeight = FontWeight.Light,
                        textAlign = TextAlign.End
                    ),
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    color = if (isDark) Color.White else Color.Black,
                    modifier = Modifier.fillMaxWidth()
                )

                // Math Result
                Text(
                    text = result,
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontSize = displayResultSize,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.End
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = if (result == "Error") ActionRed else (if (isDark) MaterialTheme.colorScheme.primary else Color(0xFF2E7D32)),
                    modifier = Modifier.fillMaxWidth().testTag("calculator_result")
                )
            }
        }

        // --- INTERACTIVE KEYPAD ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(3f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Memory operations Row (MC, MR, M+, M-)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("MC", "MR", "M+", "M-").forEach { label ->
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isDark) Color(0xFF1C222D) else Color(0xFFE3F2FD))
                            .clickable { viewModel.onCalcButton(label) }
                    ) {
                        Text(
                            text = label,
                            color = if (isDark) Color(0xFF80D8FF) else Color(0xFF0288D1),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // Expanding Scientific Operations grid
            AnimatedVisibility(
                visible = showScientific,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF10141D) else Color(0xFFF1F5F9)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val scientificRows = listOf(
                            listOf("sin", "cos", "tan", "xʸ"),
                            listOf("cosec", "sec", "cot", "√"),
                            listOf("ln", "log", "∛", "n!"),
                            listOf("π", "e", "abs", "Rand")
                        )
                        scientificRows.forEach { row ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                row.forEach { label ->
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(44.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (isDark) Color(0xFF1B2332) else Color(0xFFE1F5FE))
                                            .clickable { viewModel.onCalcButton(label) }
                                    ) {
                                        Text(
                                            text = when (label) {
                                                "xʸ" -> "x^y"
                                                "n!" -> "n!"
                                                "Rand" -> "RAND"
                                                else -> label
                                            },
                                            color = FnBlue,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Basic Grid Layout (AC, C, (), %, /, *, -, +, =, etc.)
            val buttons = listOf(
                listOf("AC", "C", "()", "%"),
                listOf("7", "8", "9", "÷"),
                listOf("4", "5", "6", "×"),
                listOf("1", "2", "3", "-"),
                listOf("0", ".", "±", "+"),
                listOf("=")
            )

            buttons.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { label ->
                        val isOperator = label in listOf("÷", "×", "-", "+", "=")
                        val isAction = label in listOf("AC", "C", "()", "%", "±")
                        
                        val btnBg = when {
                            label == "=" -> OperatorOrange
                            isOperator -> OperatorOrange.copy(alpha = 0.85f)
                            isAction -> if (isDark) Color(0xFF2C3E50) else Color(0xFFCFD8DC)
                            else -> if (isDark) NumButtonDark else NumButtonLight
                        }

                        val btnTextCol = when {
                            label == "=" -> Color.White
                            isOperator -> Color.White
                            isAction -> if (isDark) Color(0xFFE0E0E0) else Color(0xFF37474F)
                            else -> if (isDark) Color.White else Color.Black
                        }

                        val weight = if (label == "=") 4f else 1f

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .weight(weight)
                                .height(56.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(btnBg)
                                .clickable { viewModel.onCalcButton(label) }
                                .testTag("btn_$label")
                        ) {
                            Text(
                                text = label,
                                color = btnTextCol,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = if (isOperator) 22.sp else 20.sp
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
