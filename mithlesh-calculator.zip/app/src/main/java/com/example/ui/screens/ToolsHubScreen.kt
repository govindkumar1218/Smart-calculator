package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.CalculatorViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun ToolsHubScreen(viewModel: CalculatorViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("Age", "BMI", "Percentage")
    val themeMode by viewModel.theme.collectAsState()
    val isDark = themeMode != "light"

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = if (isDark) Color(0xFF161A22) else Color(0xFFECEFF1)
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = {
                        selectedTab = index
                        viewModel.vibrate()
                    },
                    text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (selectedTab) {
                0 -> AgeCalculatorTab(viewModel, isDark)
                1 -> BmiCalculatorTab(viewModel, isDark)
                2 -> PercentageCalculatorTab(viewModel, isDark)
            }
        }
    }
}

@Composable
fun AgeCalculatorTab(viewModel: CalculatorViewModel, isDark: Boolean) {
    val context = LocalContext.current
    val birthDate by viewModel.birthDate.collectAsState()
    val targetDate by viewModel.targetDate.collectAsState()

    val years by viewModel.ageYears.collectAsState()
    val months by viewModel.ageMonths.collectAsState()
    val days by viewModel.ageDays.collectAsState()

    val nextMonths by viewModel.nextBdayMonths.collectAsState()
    val nextDays by viewModel.nextBdayDays.collectAsState()

    val totalDaysBetween by viewModel.totalDaysBetween.collectAsState()

    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    Text(
        text = "Age Calculator",
        fontSize = 18.sp,
        fontWeight = FontWeight.ExtraBold,
        color = if (isDark) Color.White else Color.Black
    )

    // Selectors
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF161A22) else Color(0xFFECEFF1))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // DOB field
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isDark) Color(0xFF232B38) else Color(0xFFCFD8DC))
                    .clickable {
                        val cal = Calendar.getInstance().apply { timeInMillis = birthDate }
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                val selected = Calendar.getInstance().apply {
                                    set(Calendar.YEAR, y)
                                    set(Calendar.MONTH, m)
                                    set(Calendar.DAY_OF_MONTH, d)
                                    set(Calendar.HOUR_OF_DAY, 0)
                                    set(Calendar.MINUTE, 0)
                                    set(Calendar.SECOND, 0)
                                    set(Calendar.MILLISECOND, 0)
                                }
                                viewModel.updateBirthDate(selected.timeInMillis)
                            },
                            cal.get(Calendar.YEAR),
                            cal.get(Calendar.MONTH),
                            cal.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    }
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Date of Birth", fontSize = 11.sp, color = Color.Gray)
                    Text(sdf.format(Date(birthDate)), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Icon(Icons.Default.CalendarMonth, contentDescription = "Select DOB", tint = MaterialTheme.colorScheme.primary)
            }

            // Target Date field
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isDark) Color(0xFF232B38) else Color(0xFFCFD8DC))
                    .clickable {
                        val cal = Calendar.getInstance().apply { timeInMillis = targetDate }
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                val selected = Calendar.getInstance().apply {
                                    set(Calendar.YEAR, y)
                                    set(Calendar.MONTH, m)
                                    set(Calendar.DAY_OF_MONTH, d)
                                    set(Calendar.HOUR_OF_DAY, 0)
                                    set(Calendar.MINUTE, 0)
                                    set(Calendar.SECOND, 0)
                                    set(Calendar.MILLISECOND, 0)
                                }
                                viewModel.updateTargetDate(selected.timeInMillis)
                            },
                            cal.get(Calendar.YEAR),
                            cal.get(Calendar.MONTH),
                            cal.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    }
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Calculate Age At Date", fontSize = 11.sp, color = Color.Gray)
                    Text(sdf.format(Date(targetDate)), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Icon(Icons.Default.EventNote, contentDescription = "Select Target Date", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }

    // Exact Age Card (Triple Grid)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("YOUR EXACT AGE", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                AgeGridUnit("Years", years)
                AgeGridUnit("Months", months)
                AgeGridUnit("Days", days)
            }
        }
    }

    // Next Birthday Card
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF1E2430) else Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("NEXT BIRTHDAY IN", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (nextMonths == 0 && nextDays == 0) "Happy Birthday! 🎉" else "$nextMonths Months, $nextDays Days",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            Text(
                text = "Total Days: $totalDaysBetween",
                fontSize = 12.sp,
                color = Color.Gray,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun AgeGridUnit(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value.toString(), fontSize = 28.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
        Text(text = label, fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun BmiCalculatorTab(viewModel: CalculatorViewModel, isDark: Boolean) {
    val height by viewModel.bmiHeight.collectAsState()
    val weight by viewModel.bmiWeight.collectAsState()
    val bmiVal by viewModel.bmiResult.collectAsState()
    val category by viewModel.bmiCategory.collectAsState()
    val colCode by viewModel.bmiColor.collectAsState()

    Text(
        text = "BMI Index Calculator",
        fontSize = 18.sp,
        fontWeight = FontWeight.ExtraBold,
        color = if (isDark) Color.White else Color.Black
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF161A22) else Color(0xFFECEFF1))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = height,
                onValueChange = { viewModel.updateBmiHeight(it) },
                label = { Text("Height (cm)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = Color.Gray.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth().testTag("bmi_height_field")
            )

            OutlinedTextField(
                value = weight,
                onValueChange = { viewModel.updateBmiWeight(it) },
                label = { Text("Weight (kg)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = Color.Gray.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth().testTag("bmi_weight_field")
            )
        }
    }

    // Status report card
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(colCode).copy(alpha = 0.12f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.AccessibilityNew,
                contentDescription = "BMI Result",
                tint = Color(colCode),
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "YOUR BMI INDEX",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(colCode)
            )
            Text(
                text = bmiVal,
                fontSize = 36.sp,
                fontWeight = FontWeight.Black,
                color = if (isDark) Color.White else Color.Black,
                modifier = Modifier.testTag("bmi_result_val")
            )
            Text(
                text = category,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(colCode),
                modifier = Modifier.testTag("bmi_category_text")
            )

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = when (category) {
                    "Underweight" -> "Recommended: Eat a nutrient-rich diet & focus on building healthy mass."
                    "Normal" -> "Keep up the excellent job! Maintain your balanced nutrition and exercises."
                    "Overweight" -> "Recommended: Moderate portion controls, active walking & fitness habits."
                    "Obese" -> "Recommended: Medical guidance, strict dietary regime, and cardiovascular exercises."
                    else -> "Please enter positive height and weight coordinates."
                },
                fontSize = 11.sp,
                color = Color.Gray,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(horizontal = 8.dp),
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
fun PercentageCalculatorTab(viewModel: CalculatorViewModel, isDark: Boolean) {
    val x by viewModel.pctValueX.collectAsState()
    val y by viewModel.pctValueY.collectAsState()

    val res1 by viewModel.pctResult1.collectAsState()
    val res2 by viewModel.pctResult2.collectAsState()
    val res3 by viewModel.pctResult3.collectAsState()

    Text(
        text = "Percentage Formulas",
        fontSize = 18.sp,
        fontWeight = FontWeight.ExtraBold,
        color = if (isDark) Color.White else Color.Black
    )

    // Numeric inputs
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF161A22) else Color(0xFFECEFF1))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = x,
                onValueChange = { viewModel.updatePctValueX(it) },
                label = { Text("Value X") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = Color.Gray.copy(alpha = 0.5f)
                ),
                modifier = Modifier.weight(1f).testTag("pct_x_field")
            )

            OutlinedTextField(
                value = y,
                onValueChange = { viewModel.updatePctValueY(it) },
                label = { Text("Value Y") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = Color.Gray.copy(alpha = 0.5f)
                ),
                modifier = Modifier.weight(1f).testTag("pct_y_field")
            )
        }
    }

    // Formulas
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        // Mode 1: What is X% of Y?
        PercentageFormulaCard(
            formula = "What is $x% of $y?",
            result = res1,
            badge = "SIMPLE PCT"
        )

        // Mode 2: X is what percent of Y?
        PercentageFormulaCard(
            formula = "$x is what percent of $y?",
            result = "$res2%",
            badge = "RATIO"
        )

        // Mode 3: Percentage increase/decrease from X to Y
        val isInc = (y.toDoubleOrNull() ?: 0.0) >= (x.toDoubleOrNull() ?: 0.0)
        PercentageFormulaCard(
            formula = "Percentage change from $x to $y?",
            result = "${if (isInc) "+" else ""}$res3%",
            badge = if (isInc) "INCREASE" else "DECREASE",
            customColor = if (isInc) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
        )
    }
}

@Composable
fun PercentageFormulaCard(
    formula: String,
    result: String,
    badge: String,
    customColor: Color = MaterialTheme.colorScheme.primary
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.06f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1.5f)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(customColor.copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(text = badge, fontSize = 9.sp, color = customColor, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = formula, fontSize = 13.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
            }

            Text(
                text = result,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = customColor,
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.End
            )
        }
    }
}
