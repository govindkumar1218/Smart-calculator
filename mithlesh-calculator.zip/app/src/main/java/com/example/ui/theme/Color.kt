package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette
val LightPrimary = Color(0xFF2E7D32) // Forest green
val LightSecondary = Color(0xFF43A047)
val LightTertiary = Color(0xFF1565C0)
val LightBackground = Color(0xFFF5F5F7)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF1C1C1E)

// Dark Theme Palette (Premium Obsidian & Glass)
val DarkPrimary = Color(0xFF00E676) // Bright Neon Green Accent
val DarkSecondary = Color(0xFF00B0FF) // Cyber Cyan
val DarkTertiary = Color(0xFFFF1744) // Neon Red
val DarkBackground = Color(0xFF0B0C10) // True Midnight Black
val DarkSurface = Color(0xFF1F2833) // Deep Titanium/Obsidian Gray
val DarkOnSurface = Color(0xFFC5C6C7) // Titanium White

// Custom Button Colors (Tactile Grid Colors)
val OperatorOrange = Color(0xFFFFA000) // Vibrant Amber-Orange for operators (+, -, ×, ÷, =)
val FnBlue = Color(0xFF0288D1) // Tech Blue for scientific functions
val ActionRed = Color(0xFFD32F2F) // Action Red for AC, Delete, Clear
val NumButtonDark = Color(0xFF232B38) // Deep slate for number buttons (Dark Mode)
val NumButtonLight = Color(0xFFE0E0E0) // Light gray for number buttons (Light Mode)
