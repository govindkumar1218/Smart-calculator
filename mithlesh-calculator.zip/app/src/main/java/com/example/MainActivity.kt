package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.CalculatorScreen
import com.example.ui.screens.CurrencyConverterScreen
import com.example.ui.screens.GstScreen
import com.example.ui.screens.EmiScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ToolsHubScreen
import com.example.ui.screens.UnitConverterScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.CalculatorViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val calculatorViewModel: CalculatorViewModel = viewModel()
            val themeMode by calculatorViewModel.theme.collectAsState()

            MyApplicationTheme(
                darkTheme = themeMode != "light"
            ) {
                AppMainScaffold(calculatorViewModel)
            }
        }
    }
}

@Composable
fun AppMainScaffold(viewModel: CalculatorViewModel) {
    val navController = rememberNavController()
    val isPremium by viewModel.isPremium.collectAsState()
    val themeMode by viewModel.theme.collectAsState()
    val isDark = themeMode != "light"

    val items = listOf(
        BottomNavItem("calculator", "Calculator", Icons.Default.Calculate),
        BottomNavItem("converters", "Converters", Icons.Default.SwapHoriz),
        BottomNavItem("financials", "Financial", Icons.Default.AccountBalanceWallet),
        BottomNavItem("logs", "History", Icons.Default.History),
        BottomNavItem("settings", "Settings", Icons.Default.Settings)
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            Column(
                modifier = Modifier
                    .background(if (isDark) Color(0xFF0B0C10) else Color(0xFFF5F5F7))
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                // --- Simulated AdMob Banner ---
                SimulatedAdMobSmartBanner(
                    isPremium = isPremium,
                    onRemoveAdsClick = { viewModel.togglePremiumStatus() }
                )

                // --- Material 3 Bottom Navigation ---
                NavigationBar(
                    containerColor = if (isDark) Color(0xFF161A22) else Color(0xFFECEFF1),
                    tonalElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth().height(68.dp)
                ) {
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = navBackStackEntry?.destination?.route

                    items.forEach { item ->
                        val isSelected = currentRoute == item.route
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                viewModel.vibrate()
                                if (currentRoute != item.route) {
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.startDestinationId) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.label,
                                    modifier = Modifier.size(24.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = item.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = Color.Gray,
                                unselectedTextColor = Color.Gray,
                                indicatorColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.testTag("nav_${item.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "calculator",
            modifier = Modifier
                .fillMaxSize()
                .background(if (isDark) Color(0xFF0B0C10) else Color(0xFFF5F5F7))
                .padding(innerPadding)
        ) {
            composable("calculator") {
                CalculatorScreen(viewModel)
            }
            composable("converters") {
                ConvertersCombinedScreen(viewModel)
            }
            composable("financials") {
                FinancialsCombinedScreen(viewModel)
            }
            composable("logs") {
                HistoryScreen(viewModel)
            }
            composable("settings") {
                SettingsScreen(viewModel)
            }
        }
    }
}

// --- CONVERTERS PARENT WITH DOUBLE TABS ---
@Composable
fun ConvertersCombinedScreen(viewModel: CalculatorViewModel) {
    var subTab by remember { mutableIntStateOf(0) }
    val themeMode by viewModel.theme.collectAsState()
    val isDark = themeMode != "light"

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = subTab,
            containerColor = if (isDark) Color(0xFF161A22) else Color(0xFFECEFF1)
        ) {
            Tab(
                selected = subTab == 0,
                onClick = {
                    subTab = 0
                    viewModel.vibrate()
                },
                text = { Text("Unit Converter", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
            Tab(
                selected = subTab == 1,
                onClick = {
                    subTab = 1
                    viewModel.vibrate()
                },
                text = { Text("Currency Live", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
        }

        if (subTab == 0) {
            UnitConverterScreen(viewModel)
        } else {
            CurrencyConverterScreen(viewModel)
        }
    }
}

// --- FINANCIAL PARENT WITH TRIPLE TABS ---
@Composable
fun FinancialsCombinedScreen(viewModel: CalculatorViewModel) {
    var subTab by remember { mutableIntStateOf(0) }
    val themeMode by viewModel.theme.collectAsState()
    val isDark = themeMode != "light"

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = subTab,
            containerColor = if (isDark) Color(0xFF161A22) else Color(0xFFECEFF1)
        ) {
            Tab(
                selected = subTab == 0,
                onClick = {
                    subTab = 0
                    viewModel.vibrate()
                },
                text = { Text("EMI Loan", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
            Tab(
                selected = subTab == 1,
                onClick = {
                    subTab = 1
                    viewModel.vibrate()
                },
                text = { Text("GST Tax", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
            Tab(
                selected = subTab == 2,
                onClick = {
                    subTab = 2
                    viewModel.vibrate()
                },
                text = { Text("Quick Tools", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
        }

        when (subTab) {
            0 -> EmiScreen(viewModel)
            1 -> GstScreen(viewModel)
            2 -> ToolsHubScreen(viewModel) // BMI, Age, Percentage
        }
    }
}

// --- SIMULATED ADMOB SMART BANNER ---
@Composable
fun SimulatedAdMobSmartBanner(isPremium: Boolean, onRemoveAdsClick: () -> Unit) {
    // Ad banner completely disabled as per user request to turn off all ads.
}

data class BottomNavItem(
    val route: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)
