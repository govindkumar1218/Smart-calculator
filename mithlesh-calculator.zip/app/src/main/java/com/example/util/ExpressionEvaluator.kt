package com.example.util

import kotlin.math.*

object ExpressionEvaluator {

    fun evaluate(expression: String, isRadians: Boolean = false): Double {
        if (expression.isBlank()) return 0.0
        
        // Preprocess the input expression for tokenizing
        var cleanExpr = expression
            .replace("×", "*")
            .replace("÷", "/")
            .replace("π", Math.PI.toString())
            .replace("e", Math.E.toString())
            .replace("√", "sqrt")
            .replace("∛", "cbrt")
            .replace("cosec", "cosec")
            .replace("sec", "sec")
            .replace("cot", "cot")
            .replace("sin", "sin")
            .replace("cos", "cos")
            .replace("tan", "tan")
            .replace("ln", "ln")
            .replace("log", "log")
            .replace("abs", "abs")
            .replace("!", "fact") // factorial

        // Auto-close open parentheses if any
        val openCount = cleanExpr.count { it == '(' }
        val closeCount = cleanExpr.count { it == ')' }
        if (openCount > closeCount) {
            cleanExpr += ")".repeat(openCount - closeCount)
        }

        return try {
            Parser(cleanExpr, isRadians).parse()
        } catch (e: Exception) {
            Double.NaN
        }
    }

    private class Parser(private val str: String, private val isRadians: Boolean) {
        private var pos = -1
        private var ch = ' '

        private fun nextChar() {
            pos++
            ch = if (pos < str.length) str[pos] else '\u0000'
        }

        private fun eat(charToEat: Char): Boolean {
            while (ch == ' ') nextChar()
            if (ch == charToEat) {
                nextChar()
                return true
            }
            return false
        }

        fun parse(): Double {
            nextChar()
            val x = parseExpression()
            if (pos < str.length) throw RuntimeException("Unexpected character: $ch")
            return x
        }

        // Grammar rules:
        // expression = term | expression `+` term | expression `-` term
        // term = factor | term `*` factor | term `/` factor
        // factor = base | base `^` factor
        // base = `+` base | `-` base | `(` expression `)` | number | functionName `(` expression `)`

        private fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                if (eat('+')) x += parseTerm() // addition
                else if (eat('-')) x -= parseTerm() // subtraction
                else break
            }
            return x
        }

        private fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                if (eat('*')) x *= parseFactor() // multiplication
                else if (eat('/')) {
                    val divisor = parseFactor()
                    if (divisor == 0.0) throw ArithmeticException("Division by zero")
                    x /= divisor // division
                } else break
            }
            return x
        }

        private fun parseFactor(): Double {
            var x = parseBase()
            while (true) {
                if (eat('^')) {
                    x = x.pow(parseFactor()) // power (right associative)
                } else break
            }
            return x
        }

        private fun parseBase(): Double {
            if (eat('+')) return parseBase() // unary plus
            if (eat('-')) return -parseBase() // unary minus

            var x: Double
            val startPos = this.pos
            if (eat('(')) { // parentheses
                x = parseExpression()
                eat(')')
            } else if ((ch in '0'..'9') || ch == '.') { // numbers
                while ((ch in '0'..'9') || ch == '.') nextChar()
                x = str.substring(startPos, this.pos).toDouble()
            } else if (ch in 'a'..'z' || ch in 'A'..'Z') { // functions or constants
                while (ch in 'a'..'z' || ch in 'A'..'Z') nextChar()
                val func = str.substring(startPos, this.pos)
                if (func == "rand") {
                    x = Math.random()
                } else {
                    if (!eat('(')) throw RuntimeException("Expected '(' after function name $func")
                    val arg = parseExpression()
                    if (!eat(')')) throw RuntimeException("Expected ')' after function argument")
                    
                    x = when (func) {
                        "sin" -> sin(if (isRadians) arg else Math.toRadians(arg))
                        "cos" -> cos(if (isRadians) arg else Math.toRadians(arg))
                        "tan" -> tan(if (isRadians) arg else Math.toRadians(arg))
                        "cosec" -> {
                            val s = sin(if (isRadians) arg else Math.toRadians(arg))
                            if (s == 0.0) throw ArithmeticException("Cosec division by zero")
                            1.0 / s
                        }
                        "sec" -> {
                            val c = cos(if (isRadians) arg else Math.toRadians(arg))
                            if (c == 0.0) throw ArithmeticException("Sec division by zero")
                            1.0 / c
                        }
                        "cot" -> {
                            val t = tan(if (isRadians) arg else Math.toRadians(arg))
                            if (t == 0.0) throw ArithmeticException("Cot division by zero")
                            1.0 / t
                        }
                        "sqrt" -> {
                            if (arg < 0.0) throw ArithmeticException("Negative square root")
                            sqrt(arg)
                        }
                        "cbrt" -> Math.cbrt(arg)
                        "ln" -> ln(arg)
                        "log" -> log10(arg)
                        "abs" -> abs(arg)
                        "fact" -> factorial(arg)
                        else -> throw RuntimeException("Unknown function: $func")
                    }
                }
            } else {
                throw RuntimeException("Unexpected: $ch")
            }

            // Postfix factorial support (e.g. 5!) - if evaluated factor is followed immediately by ! or we pre-mapped ! to fact
            return x
        }

        private fun factorial(n: Double): Double {
            if (n < 0.0) return Double.NaN
            if (n == 0.0 || n == 1.0) return 1.0
            val l = n.toLong()
            if (l.toDouble() == n) {
                var res = 1.0
                for (i in 2..l) {
                    res *= i
                }
                return res
            }
            // gamma function approximation for non-integers (Lanczos approximation style or fallback)
            return Double.NaN
        }
    }
}
