package com.example.util

object UnitConverter {

    fun convert(category: String, value: Double, fromUnit: String, toUnit: String): Double {
        if (fromUnit == toUnit) return value
        return when (category) {
            "Length" -> convertLength(value, fromUnit, toUnit)
            "Weight" -> convertWeight(value, fromUnit, toUnit)
            "Area" -> convertArea(value, fromUnit, toUnit)
            "Volume" -> convertVolume(value, fromUnit, toUnit)
            "Temperature" -> convertTemperature(value, fromUnit, toUnit)
            "Time" -> convertTime(value, fromUnit, toUnit)
            "Speed" -> convertSpeed(value, fromUnit, toUnit)
            "Pressure" -> convertPressure(value, fromUnit, toUnit)
            "Data Storage" -> convertData(value, fromUnit, toUnit)
            else -> value
        }
    }

    private fun convertLength(value: Double, from: String, to: String): Double {
        // base unit: Meter
        val toMeter = when (from) {
            "Meter (m)" -> 1.0
            "Kilometer (km)" -> 1000.0
            "Centimeter (cm)" -> 0.01
            "Millimeter (mm)" -> 0.001
            "Mile (mi)" -> 1609.344
            "Yard (yd)" -> 0.9144
            "Foot (ft)" -> 0.3048
            "Inch (in)" -> 0.0254
            else -> 1.0
        }
        val meter = value * toMeter
        val fromMeter = when (to) {
            "Meter (m)" -> 1.0
            "Kilometer (km)" -> 0.001
            "Centimeter (cm)" -> 100.0
            "Millimeter (mm)" -> 1000.0
            "Mile (mi)" -> 1.0 / 1609.344
            "Yard (yd)" -> 1.0 / 0.9144
            "Foot (ft)" -> 1.0 / 0.3048
            "Inch (in)" -> 1.0 / 0.0254
            else -> 1.0
        }
        return meter * fromMeter
    }

    private fun convertWeight(value: Double, from: String, to: String): Double {
        // base unit: Gram
        val toGram = when (from) {
            "Kilogram (kg)" -> 1000.0
            "Gram (g)" -> 1.0
            "Milligram (mg)" -> 0.001
            "Pound (lb)" -> 453.59237
            "Ounce (oz)" -> 28.349523
            else -> 1.0
        }
        val gram = value * toGram
        val fromGram = when (to) {
            "Kilogram (kg)" -> 0.001
            "Gram (g)" -> 1.0
            "Milligram (mg)" -> 1000.0
            "Pound (lb)" -> 1.0 / 453.59237
            "Ounce (oz)" -> 1.0 / 28.349523
            else -> 1.0
        }
        return gram * fromGram
    }

    private fun convertArea(value: Double, from: String, to: String): Double {
        // base unit: Square Meter
        val toSqMeter = when (from) {
            "Square Meter (m²)" -> 1.0
            "Square Kilometer (km²)" -> 1000000.0
            "Square Mile (mi²)" -> 2589988.11
            "Acre" -> 4046.856
            "Hectare" -> 10000.0
            else -> 1.0
        }
        val sqMeter = value * toSqMeter
        val fromSqMeter = when (to) {
            "Square Meter (m²)" -> 1.0
            "Square Kilometer (km²)" -> 0.000001
            "Square Mile (mi²)" -> 1.0 / 2589988.11
            "Acre" -> 1.0 / 4046.856
            "Hectare" -> 0.0001
            else -> 1.0
        }
        return sqMeter * fromSqMeter
    }

    private fun convertVolume(value: Double, from: String, to: String): Double {
        // base unit: Liter
        val toLiter = when (from) {
            "Liter (L)" -> 1.0
            "Milliliter (mL)" -> 0.001
            "Gallon (gal)" -> 3.78541
            "Quart (qt)" -> 0.946353
            "Cup" -> 0.236588
            else -> 1.0
        }
        val liter = value * toLiter
        val fromLiter = when (to) {
            "Liter (L)" -> 1.0
            "Milliliter (mL)" -> 1000.0
            "Gallon (gal)" -> 1.0 / 3.78541
            "Quart (qt)" -> 1.0 / 0.946353
            "Cup" -> 1.0 / 0.236588
            else -> 1.0
        }
        return liter * fromLiter
    }

    private fun convertTemperature(value: Double, from: String, to: String): Double {
        // First convert to Celsius
        val celsius = when (from) {
            "Celsius (°C)" -> value
            "Fahrenheit (°F)" -> (value - 32.0) * 5.0 / 9.0
            "Kelvin (K)" -> value - 273.15
            else -> value
        }
        // Celsius to output
        return when (to) {
            "Celsius (°C)" -> celsius
            "Fahrenheit (°F)" -> celsius * 9.0 / 5.0 + 32.0
            "Kelvin (K)" -> celsius + 273.15
            else -> celsius
        }
    }

    private fun convertTime(value: Double, from: String, to: String): Double {
        // base unit: Second
        val toSecond = when (from) {
            "Second (s)" -> 1.0
            "Minute (min)" -> 60.0
            "Hour (h)" -> 3600.0
            "Day (d)" -> 86400.0
            "Week" -> 604800.0
            "Year" -> 31536000.0
            else -> 1.0
        }
        val second = value * toSecond
        val fromSecond = when (to) {
            "Second (s)" -> 1.0
            "Minute (min)" -> 1.0 / 60.0
            "Hour (h)" -> 1.0 / 3600.0
            "Day (d)" -> 1.0 / 86400.0
            "Week" -> 1.0 / 604800.0
            "Year" -> 1.0 / 31536000.0
            else -> 1.0
        }
        return second * fromSecond
    }

    private fun convertSpeed(value: Double, from: String, to: String): Double {
        // base unit: m/s
        val toMS = when (from) {
            "Meter/sec (m/s)" -> 1.0
            "Kilometer/hr (km/h)" -> 0.277778
            "Miles/hr (mph)" -> 0.44704
            "Knot" -> 0.514444
            else -> 1.0
        }
        val ms = value * toMS
        val fromMS = when (to) {
            "Meter/sec (m/s)" -> 1.0
            "Kilometer/hr (km/h)" -> 3.6
            "Miles/hr (mph)" -> 2.23694
            "Knot" -> 1.94384
            else -> 1.0
        }
        return ms * fromMS
    }

    private fun convertPressure(value: Double, from: String, to: String): Double {
        // base unit: Pascal
        val toPa = when (from) {
            "Pascal (Pa)" -> 1.0
            "Bar" -> 100000.0
            "Atmosphere (atm)" -> 101325.0
            "PSI" -> 6894.76
            else -> 1.0
        }
        val pa = value * toPa
        val fromPa = when (to) {
            "Pascal (Pa)" -> 1.0
            "Bar" -> 0.00001
            "Atmosphere (atm)" -> 1.0 / 101325.0
            "PSI" -> 1.0 / 6894.76
            else -> 1.0
        }
        return pa * fromPa
    }

    private fun convertData(value: Double, from: String, to: String): Double {
        // base unit: Byte
        val toByte = when (from) {
            "Byte (B)" -> 1.0
            "Kilobyte (KB)" -> 1024.0
            "Megabyte (MB)" -> 1048576.0
            "Gigabyte (GB)" -> 1073741824.0
            "Terabyte (TB)" -> 1099511627776.0
            else -> 1.0
        }
        val bytes = value * toByte
        val fromByte = when (to) {
            "Byte (B)" -> 1.0
            "Kilobyte (KB)" -> 1.0 / 1024.0
            "Megabyte (MB)" -> 1.0 / 1048576.0
            "Gigabyte (GB)" -> 1.0 / 1073741824.0
            "Terabyte (TB)" -> 1.0 / 1099511627776.0
            else -> 1.0
        }
        return bytes * fromByte
    }

    fun getUnits(category: String): List<String> {
        return when (category) {
            "Length" -> listOf("Meter (m)", "Kilometer (km)", "Centimeter (cm)", "Millimeter (mm)", "Mile (mi)", "Yard (yd)", "Foot (ft)", "Inch (in)")
            "Weight" -> listOf("Kilogram (kg)", "Gram (g)", "Milligram (mg)", "Pound (lb)", "Ounce (oz)")
            "Area" -> listOf("Square Meter (m²)", "Square Kilometer (km²)", "Square Mile (mi²)", "Acre", "Hectare")
            "Volume" -> listOf("Liter (L)", "Milliliter (mL)", "Gallon (gal)", "Quart (qt)", "Cup")
            "Temperature" -> listOf("Celsius (°C)", "Fahrenheit (°F)", "Kelvin (K)")
            "Time" -> listOf("Second (s)", "Minute (min)", "Hour (h)", "Day (d)", "Week", "Year")
            "Speed" -> listOf("Meter/sec (m/s)", "Kilometer/hr (km/h)", "Miles/hr (mph)", "Knot")
            "Pressure" -> listOf("Pascal (Pa)", "Bar", "Atmosphere (atm)", "PSI")
            "Data Storage" -> listOf("Byte (B)", "Kilobyte (KB)", "Megabyte (MB)", "Gigabyte (GB)", "Terabyte (TB)")
            else -> emptyList()
        }
    }
}
