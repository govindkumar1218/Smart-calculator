package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.CalculatorRepository
import com.example.data.CurrencyClient
import com.example.data.CurrencyRateEntity
import com.example.util.ExpressionEvaluator
import com.example.util.UnitConverter
import kotlin.math.abs
import kotlin.math.pow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CalculatorRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = CalculatorRepository(database)
    }

    // --- History Flow ---
    val historyList: StateFlow<List<com.example.data.HistoryEntity>> = repository.allHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<com.example.data.HistoryEntity>>(emptyList())
    val searchResults = _searchResults.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        viewModelScope.launch {
            if (query.isBlank()) {
                _searchResults.value = emptyList()
            } else {
                repository.searchHistory(query).collectLatest {
                    _searchResults.value = it
                }
            }
        }
    }

    fun toggleFavorite(id: Int, current: Boolean) {
        viewModelScope.launch {
            repository.toggleFavorite(id, current)
            vibrate()
        }
    }

    fun deleteHistoryItem(id: Int) {
        viewModelScope.launch {
            repository.deleteHistory(id)
            vibrate()
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            vibrate()
        }
    }

    // --- Settings & Personalization ---
    private val _theme = MutableStateFlow("dark") // dark, light, system, dynamic
    val theme: StateFlow<String> = _theme.asStateFlow()

    private val _fontSize = MutableStateFlow("normal") // small, normal, large
    val fontSize: StateFlow<String> = _fontSize.asStateFlow()

    private val _soundEnabled = MutableStateFlow(true)
    val soundEnabled: StateFlow<Boolean> = _soundEnabled.asStateFlow()

    private val _vibrationEnabled = MutableStateFlow(true)
    val vibrationEnabled: StateFlow<Boolean> = _vibrationEnabled.asStateFlow()

    private val _isPremium = MutableStateFlow(false)
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()

    private val _language = MutableStateFlow("en") // en, hi
    val language: StateFlow<String> = _language.asStateFlow()

    init {
        // Load initial settings
        viewModelScope.launch {
            _theme.value = repository.getSetting("theme", "dark")
            _fontSize.value = repository.getSetting("fontSize", "normal")
            _soundEnabled.value = repository.getSetting("soundEnabled", "true").toBoolean()
            _vibrationEnabled.value = repository.getSetting("vibrationEnabled", "true").toBoolean()
            _isPremium.value = repository.getSetting("isPremium", "true").toBoolean()
            _language.value = repository.getSetting("language", "en")
        }
    }

    fun updateTheme(newTheme: String) {
        _theme.value = newTheme
        viewModelScope.launch { repository.saveSetting("theme", newTheme) }
        vibrate()
    }

    fun updateFontSize(newSize: String) {
        _fontSize.value = newSize
        viewModelScope.launch { repository.saveSetting("fontSize", newSize) }
        vibrate()
    }

    fun toggleSound() {
        val next = !_soundEnabled.value
        _soundEnabled.value = next
        viewModelScope.launch { repository.saveSetting("soundEnabled", next.toString()) }
        vibrate()
    }

    fun toggleVibration() {
        val next = !_vibrationEnabled.value
        _vibrationEnabled.value = next
        viewModelScope.launch { repository.saveSetting("vibrationEnabled", next.toString()) }
        vibrate()
    }

    fun togglePremiumStatus() {
        val next = !_isPremium.value
        _isPremium.value = next
        viewModelScope.launch { repository.saveSetting("isPremium", next.toString()) }
        vibrate()
    }

    fun updateLanguage(newLang: String) {
        _language.value = newLang
        viewModelScope.launch { repository.saveSetting("language", newLang) }
        vibrate()
    }

    // --- Sound & Vibration Haptics ---
    fun playButtonSound() {
        if (_soundEnabled.value) {
            try {
                val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
                toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 30)
            } catch (e: Exception) {
                // fallbacks
            }
        }
    }

    fun vibrate() {
        if (_vibrationEnabled.value) {
            val vibrator = getApplication<Application>().getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            vibrator?.let {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    it.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    it.vibrate(25)
                }
            }
        }
    }

    // --- Basic & Scientific Calculator Core ---
    private val _calcInput = MutableStateFlow("")
    val calcInput: StateFlow<String> = _calcInput.asStateFlow()

    private val _calcResult = MutableStateFlow("")
    val calcResult: StateFlow<String> = _calcResult.asStateFlow()

    private val _isRadians = MutableStateFlow(false)
    val isRadians: StateFlow<Boolean> = _isRadians.asStateFlow()

    private val _memory = MutableStateFlow(0.0)
    val memory: StateFlow<Double> = _memory.asStateFlow()

    private val decimalFormat = DecimalFormat("#.#########")

    fun onCalcButton(label: String) {
        playButtonSound()
        vibrate()

        when (label) {
            "AC" -> {
                _calcInput.value = ""
                _calcResult.value = ""
            }
            "C" -> {
                val cur = _calcInput.value
                if (cur.isNotEmpty()) {
                    _calcInput.value = cur.substring(0, cur.length - 1)
                }
            }
            "=" -> {
                evaluateCalculator()
            }
            "±" -> {
                val cur = _calcInput.value
                if (cur.isNotEmpty()) {
                    if (cur.startsWith("-")) {
                        _calcInput.value = cur.substring(1)
                    } else {
                        _calcInput.value = "-$cur"
                    }
                }
            }
            "M+" -> {
                val resVal = _calcResult.value.toDoubleOrNull() ?: _calcInput.value.toDoubleOrNull() ?: 0.0
                _memory.value += resVal
            }
            "M-" -> {
                val resVal = _calcResult.value.toDoubleOrNull() ?: _calcInput.value.toDoubleOrNull() ?: 0.0
                _memory.value -= resVal
            }
            "MR" -> {
                _calcInput.value += decimalFormat.format(_memory.value)
            }
            "MC" -> {
                _memory.value = 0.0
            }
            "sin", "cos", "tan", "cosec", "sec", "cot", "ln", "log", "abs", "√", "∛" -> {
                _calcInput.value += "$label("
            }
            "x²" -> {
                _calcInput.value += "^2"
            }
            "x³" -> {
                _calcInput.value += "^3"
            }
            "xʸ" -> {
                _calcInput.value += "^"
            }
            "n!" -> {
                _calcInput.value += "!"
            }
            "π" -> {
                _calcInput.value += "π"
            }
            "e" -> {
                _calcInput.value += "e"
            }
            "Rand" -> {
                _calcInput.value += "rand"
            }
            else -> {
                _calcInput.value += label
            }
        }
    }

    fun toggleRadians() {
        _isRadians.value = !_isRadians.value
        vibrate()
        if (_calcInput.value.isNotEmpty()) {
            evaluateCalculator()
        }
    }

    private fun evaluateCalculator() {
        val inputStr = _calcInput.value
        if (inputStr.isBlank()) return
        viewModelScope.launch(Dispatchers.Default) {
            val eval = ExpressionEvaluator.evaluate(inputStr, _isRadians.value)
            if (eval.isNaN() || eval.isInfinite()) {
                _calcResult.value = "Error"
            } else {
                val formatted = decimalFormat.format(eval)
                _calcResult.value = formatted
                // Save to history automatically on press '='
                repository.addHistory(inputStr, formatted, "basic")
            }
        }
    }

    // --- Unit Converter Core ---
    private val _unitCategory = MutableStateFlow("Length")
    val unitCategory = _unitCategory.asStateFlow()

    private val _unitInputVal = MutableStateFlow("1")
    val unitInputVal = _unitInputVal.asStateFlow()

    private val _unitFrom = MutableStateFlow("Meter (m)")
    val unitFrom = _unitFrom.asStateFlow()

    private val _unitTo = MutableStateFlow("Centimeter (cm)")
    val unitTo = _unitTo.asStateFlow()

    private val _unitResultVal = MutableStateFlow("100")
    val unitResultVal = _unitResultVal.asStateFlow()

    fun updateUnitCategory(cat: String) {
        _unitCategory.value = cat
        val units = UnitConverter.getUnits(cat)
        if (units.isNotEmpty()) {
            _unitFrom.value = units[0]
            _unitTo.value = if (units.size > 1) units[1] else units[0]
        }
        recalculateUnit()
        vibrate()
    }

    fun updateUnitInput(input: String) {
        _unitInputVal.value = input
        recalculateUnit()
    }

    fun updateUnitFrom(from: String) {
        _unitFrom.value = from
        recalculateUnit()
    }

    fun updateUnitTo(to: String) {
        _unitTo.value = to
        recalculateUnit()
    }

    private fun recalculateUnit() {
        val value = _unitInputVal.value.toDoubleOrNull() ?: 0.0
        val cat = _unitCategory.value
        val from = _unitFrom.value
        val to = _unitTo.value
        viewModelScope.launch(Dispatchers.Default) {
            val converted = UnitConverter.convert(cat, value, from, to)
            _unitResultVal.value = decimalFormat.format(converted)
        }
    }

    // --- Currency Converter Core ---
    private val _currencyRates = MutableStateFlow(CurrencyClient.defaultRates)
    val currencyRates = _currencyRates.asStateFlow()

    private val _currencyInput = MutableStateFlow("100")
    val currencyInput = _currencyInput.asStateFlow()

    private val _currencyFrom = MutableStateFlow("USD")
    val currencyFrom = _currencyFrom.asStateFlow()

    private val _currencyTo = MutableStateFlow("INR")
    val currencyTo = _currencyTo.asStateFlow()

    private val _currencyResult = MutableStateFlow("8350")
    val currencyResult = _currencyResult.asStateFlow()

    private val _isRefreshingRates = MutableStateFlow(false)
    val isRefreshingRates = _isRefreshingRates.asStateFlow()

    private val _rateStatus = MutableStateFlow("Rates cached offline")
    val rateStatus = _rateStatus.asStateFlow()

    init {
        // Load offline rates from Room database if present, otherwise fetch live
        viewModelScope.launch {
            repository.cachedRates.collectLatest { dbRates ->
                if (dbRates.isNotEmpty()) {
                    val map = dbRates.associate { it.code to it.rate }
                    _currencyRates.value = map
                    _rateStatus.value = "Offline cached rates loaded"
                    recalculateCurrency()
                } else {
                    // Seed initial offline defaults
                    val seed = CurrencyClient.defaultRates.map { (k, v) -> CurrencyRateEntity(k, v) }
                    repository.saveRates(seed)
                }
            }
        }
        fetchLiveCurrencyRates()
    }

    fun fetchLiveCurrencyRates() {
        viewModelScope.launch(Dispatchers.IO) {
            _isRefreshingRates.value = true
            _rateStatus.value = "Syncing live rates..."
            try {
                val resp = CurrencyClient.api.getLatestRates()
                if (resp.result == "success") {
                    val entities = resp.rates.map { (code, rate) -> CurrencyRateEntity(code, rate) }
                    repository.saveRates(entities)
                    _currencyRates.value = resp.rates
                    _rateStatus.value = "Live currency sync success"
                } else {
                    _rateStatus.value = "Sync error: status non-success"
                }
            } catch (e: Exception) {
                _rateStatus.value = "Offline mode: Failed to sync live rates"
            } finally {
                _isRefreshingRates.value = false
                recalculateCurrency()
            }
        }
    }

    fun updateCurrencyInput(input: String) {
        _currencyInput.value = input
        recalculateCurrency()
    }

    fun updateCurrencyFrom(from: String) {
        _currencyFrom.value = from
        recalculateCurrency()
    }

    fun updateCurrencyTo(to: String) {
        _currencyTo.value = to
        recalculateCurrency()
    }

    fun swapCurrencies() {
        val temp = _currencyFrom.value
        _currencyFrom.value = _currencyTo.value
        _currencyTo.value = temp
        recalculateCurrency()
        vibrate()
    }

    private fun recalculateCurrency() {
        val amount = _currencyInput.value.toDoubleOrNull() ?: 0.0
        val rates = _currencyRates.value
        val from = _currencyFrom.value
        val to = _currencyTo.value

        val fromRate = rates[from] ?: 1.0
        val toRate = rates[to] ?: 1.0

        // Convert to USD base first, then convert to target
        val amountInUSD = amount / fromRate
        val result = amountInUSD * toRate
        _currencyResult.value = decimalFormat.format(result)
    }

    // --- Age Calculator Core ---
    private val _birthDate = MutableStateFlow<Long>(
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    )
    val birthDate = _birthDate.asStateFlow()

    private val _targetDate = MutableStateFlow<Long>(
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    )
    val targetDate = _targetDate.asStateFlow()

    // Results
    private val _ageYears = MutableStateFlow(0)
    val ageYears = _ageYears.asStateFlow()

    private val _ageMonths = MutableStateFlow(0)
    val ageMonths = _ageMonths.asStateFlow()

    private val _ageDays = MutableStateFlow(0)
    val ageDays = _ageDays.asStateFlow()

    private val _nextBdayMonths = MutableStateFlow(0)
    val nextBdayMonths = _nextBdayMonths.asStateFlow()

    private val _nextBdayDays = MutableStateFlow(0)
    val nextBdayDays = _nextBdayDays.asStateFlow()

    private val _totalDaysBetween = MutableStateFlow(0L)
    val totalDaysBetween = _totalDaysBetween.asStateFlow()

    fun updateBirthDate(ms: Long) {
        val normalized = Calendar.getInstance().apply {
            timeInMillis = ms
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        _birthDate.value = normalized.timeInMillis
        calculateAge()
    }

    fun updateTargetDate(ms: Long) {
        val normalized = Calendar.getInstance().apply {
            timeInMillis = ms
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        _targetDate.value = normalized.timeInMillis
        calculateAge()
    }

    private fun calculateAge() {
        val dob = Calendar.getInstance().apply {
            timeInMillis = _birthDate.value
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val target = Calendar.getInstance().apply {
            timeInMillis = _targetDate.value
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (dob.after(target)) {
            _ageYears.value = 0
            _ageMonths.value = 0
            _ageDays.value = 0
            _nextBdayMonths.value = 0
            _nextBdayDays.value = 0
            _totalDaysBetween.value = 0L
            return
        }

        val years = target.get(Calendar.YEAR) - dob.get(Calendar.YEAR)
        var months = target.get(Calendar.MONTH) - dob.get(Calendar.MONTH)
        var days = target.get(Calendar.DAY_OF_MONTH) - dob.get(Calendar.DAY_OF_MONTH)

        if (days < 0) {
            months--
            // Borrow days from previous month of target
            val prevMonth = target.clone() as Calendar
            prevMonth.add(Calendar.MONTH, -1)
            days += prevMonth.getActualMaximum(Calendar.DAY_OF_MONTH)
        }
        if (months < 0) {
            months += 12
        }
        val finalYears = if (target.get(Calendar.MONTH) < dob.get(Calendar.MONTH) ||
            (target.get(Calendar.MONTH) == dob.get(Calendar.MONTH) && target.get(Calendar.DAY_OF_MONTH) < dob.get(Calendar.DAY_OF_MONTH))
        ) {
            years - 1
        } else {
            years
        }

        _ageYears.value = finalYears
        _ageMonths.value = months
        _ageDays.value = days

        // Total Days Between
        val diffMs = abs(target.timeInMillis - dob.timeInMillis)
        _totalDaysBetween.value = diffMs / (1000 * 60 * 60 * 24)

        // Next Birthday
        val nextBday = Calendar.getInstance().apply {
            timeInMillis = target.timeInMillis
            set(Calendar.MONTH, dob.get(Calendar.MONTH))
            set(Calendar.DAY_OF_MONTH, dob.get(Calendar.DAY_OF_MONTH))
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (nextBday.before(target) || nextBday.equals(target)) {
            nextBday.add(Calendar.YEAR, 1)
        }

        var bdayDiffMonths = nextBday.get(Calendar.MONTH) - target.get(Calendar.MONTH)
        var bdayDiffDays = nextBday.get(Calendar.DAY_OF_MONTH) - target.get(Calendar.DAY_OF_MONTH)

        if (bdayDiffDays < 0) {
            bdayDiffMonths--
            val prev = nextBday.clone() as Calendar
            prev.add(Calendar.MONTH, -1)
            bdayDiffDays += prev.getActualMaximum(Calendar.DAY_OF_MONTH)
        }
        if (bdayDiffMonths < 0) {
            bdayDiffMonths += 12
        }

        _nextBdayMonths.value = bdayDiffMonths
        _nextBdayDays.value = bdayDiffDays
    }

    // --- GST Calculator Core ---
    private val _gstAmount = MutableStateFlow("5000")
    val gstAmount = _gstAmount.asStateFlow()

    private val _gstRate = MutableStateFlow(18.0)
    val gstRate = _gstRate.asStateFlow()

    // Calculated fields
    private val _gstAddedTotal = MutableStateFlow("5900")
    val gstAddedTotal = _gstAddedTotal.asStateFlow()

    private val _gstAddedValue = MutableStateFlow("900")
    val gstAddedValue = _gstAddedValue.asStateFlow()

    private val _gstRemovedTotal = MutableStateFlow("4237.29")
    val gstRemovedTotal = _gstRemovedTotal.asStateFlow()

    private val _gstRemovedValue = MutableStateFlow("762.71")
    val gstRemovedValue = _gstRemovedValue.asStateFlow()

    fun updateGstAmount(input: String) {
        _gstAmount.value = input
        recalculateGst()
    }

    fun updateGstRate(rate: Double) {
        _gstRate.value = rate
        recalculateGst()
    }

    private fun recalculateGst() {
        val amount = _gstAmount.value.toDoubleOrNull() ?: 0.0
        val rate = _gstRate.value

        val gstAdd = amount * (rate / 100.0)
        val totalAdd = amount + gstAdd

        val totalRemove = amount / (1.0 + (rate / 100.0))
        val gstRemove = amount - totalRemove

        val df = DecimalFormat("#.##")
        _gstAddedTotal.value = df.format(totalAdd)
        _gstAddedValue.value = df.format(gstAdd)
        _gstRemovedTotal.value = df.format(totalRemove)
        _gstRemovedValue.value = df.format(gstRemove)
    }

    // --- EMI Calculator Core ---
    private val _emiPrincipal = MutableStateFlow("100000")
    val emiPrincipal = _emiPrincipal.asStateFlow()

    private val _emiInterest = MutableStateFlow("10") // annual interest %
    val emiInterest = _emiInterest.asStateFlow()

    private val _emiTenure = MutableStateFlow("12") // months
    val emiTenure = _emiTenure.asStateFlow()

    // Results
    private val _emiMonthlyPay = MutableStateFlow("8791.59")
    val emiMonthlyPay = _emiMonthlyPay.asStateFlow()

    private val _emiTotalInterest = MutableStateFlow("5499.06")
    val emiTotalInterest = _emiTotalInterest.asStateFlow()

    private val _emiTotalPayable = MutableStateFlow("105499.06")
    val emiTotalPayable = _emiTotalPayable.asStateFlow()

    fun updateEmiPrincipal(input: String) {
        _emiPrincipal.value = input
        recalculateEmi()
    }

    fun updateEmiInterest(input: String) {
        _emiInterest.value = input
        recalculateEmi()
    }

    fun updateEmiTenure(input: String) {
        _emiTenure.value = input
        recalculateEmi()
    }

    private fun recalculateEmi() {
        val p = _emiPrincipal.value.toDoubleOrNull() ?: 0.0
        val rYear = _emiInterest.value.toDoubleOrNull() ?: 0.0
        val n = _emiTenure.value.toDoubleOrNull() ?: 0.0

        if (p <= 0.0 || rYear <= 0.0 || n <= 0.0) {
            _emiMonthlyPay.value = "0.0"
            _emiTotalInterest.value = "0.0"
            _emiTotalPayable.value = "0.0"
            return
        }

        val r = (rYear / 12.0) / 100.0 // monthly interest
        val monthlyPay = (p * r * (1.0 + r).pow(n)) / ((1.0 + r).pow(n) - 1.0)
        val totalPay = monthlyPay * n
        val totalInterest = totalPay - p

        val df = DecimalFormat("#.##")
        _emiMonthlyPay.value = df.format(monthlyPay)
        _emiTotalInterest.value = df.format(totalInterest)
        _emiTotalPayable.value = df.format(totalPay)
    }

    // --- BMI Calculator Core ---
    private val _bmiHeight = MutableStateFlow("170") // cm
    val bmiHeight = _bmiHeight.asStateFlow()

    private val _bmiWeight = MutableStateFlow("70") // kg
    val bmiWeight = _bmiWeight.asStateFlow()

    // Results
    private val _bmiResult = MutableStateFlow("24.2")
    val bmiResult = _bmiResult.asStateFlow()

    private val _bmiCategory = MutableStateFlow("Normal")
    val bmiCategory = _bmiCategory.asStateFlow()

    private val _bmiColor = MutableStateFlow(0xFF4CAF50) // Hex color code
    val bmiColor = _bmiColor.asStateFlow()

    fun updateBmiHeight(input: String) {
        _bmiHeight.value = input
        recalculateBmi()
    }

    fun updateBmiWeight(input: String) {
        _bmiWeight.value = input
        recalculateBmi()
    }

    private fun recalculateBmi() {
        val heightCm = _bmiHeight.value.toDoubleOrNull() ?: 0.0
        val weightKg = _bmiWeight.value.toDoubleOrNull() ?: 0.0

        if (heightCm <= 0.0 || weightKg <= 0.0) {
            _bmiResult.value = "0.0"
            _bmiCategory.value = "Enter parameters"
            _bmiColor.value = 0xFF757575
            return
        }

        val heightM = heightCm / 100.0
        val bmi = weightKg / (heightM * heightM)

        val df = DecimalFormat("#.#")
        _bmiResult.value = df.format(bmi)

        val (cat, color) = when {
            bmi < 18.5 -> "Underweight" to 0xFF2196F3 // Blue
            bmi in 18.5..24.9 -> "Normal" to 0xFF4CAF50 // Green
            bmi in 25.0..29.9 -> "Overweight" to 0xFFFF9800 // Orange
            else -> "Obese" to 0xFFF44336 // Red
        }
        _bmiCategory.value = cat
        _bmiColor.value = color
    }

    // --- Percentage Calculator Core ---
    private val _pctValueX = MutableStateFlow("15")
    val pctValueX = _pctValueX.asStateFlow()

    private val _pctValueY = MutableStateFlow("200")
    val pctValueY = _pctValueY.asStateFlow()

    // Results
    private val _pctResult1 = MutableStateFlow("30") // Mode 1: What is X% of Y?
    private val _pctResult2 = MutableStateFlow("7.5") // Mode 2: X is what percent of Y?
    private val _pctResult3 = MutableStateFlow("1233.33") // Mode 3: Percentage increase from X to Y

    val pctResult1 = _pctResult1.asStateFlow()
    val pctResult2 = _pctResult2.asStateFlow()
    val pctResult3 = _pctResult3.asStateFlow()

    fun updatePctValueX(input: String) {
        _pctValueX.value = input
        recalculatePercentage()
    }

    fun updatePctValueY(input: String) {
        _pctValueY.value = input
        recalculatePercentage()
    }

    private fun recalculatePercentage() {
        val x = _pctValueX.value.toDoubleOrNull() ?: 0.0
        val y = _pctValueY.value.toDoubleOrNull() ?: 0.0

        val df = DecimalFormat("#.##")

        // Mode 1: what is x% of y?
        val r1 = (x / 100.0) * y
        _pctResult1.value = df.format(r1)

        // Mode 2: x is what % of y?
        val r2 = if (y != 0.0) (x / y) * 100.0 else 0.0
        _pctResult2.value = df.format(r2)

        // Mode 3: pct change from x to y?
        val r3 = if (x != 0.0) ((y - x) / x) * 100.0 else 0.0
        _pctResult3.value = df.format(r3)
    }

    // Seed/Restore Helper
    fun backupData(): String {
        vibrate()
        // Simple JSON backup generator of settings
        return "MITHLESH_BACKUP_v1,theme:${_theme.value},sound:${_soundEnabled.value},vibration:${_vibrationEnabled.value},fontSize:${_fontSize.value},language:${_language.value}"
    }

    fun restoreData(backup: String): Boolean {
        vibrate()
        try {
            if (backup.startsWith("MITHLESH_BACKUP_v1")) {
                val parts = backup.split(",")
                for (i in 1 until parts.size) {
                    val kv = parts[i].split(":")
                    if (kv.size == 2) {
                        val k = kv[0]
                        val v = kv[1]
                        when (k) {
                            "theme" -> updateTheme(v)
                            "sound" -> {
                                _soundEnabled.value = v.toBoolean()
                                viewModelScope.launch { repository.saveSetting("soundEnabled", v) }
                            }
                            "vibration" -> {
                                _vibrationEnabled.value = v.toBoolean()
                                viewModelScope.launch { repository.saveSetting("vibrationEnabled", v) }
                            }
                            "fontSize" -> updateFontSize(v)
                            "language" -> updateLanguage(v)
                        }
                    }
                }
                return true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }
}
