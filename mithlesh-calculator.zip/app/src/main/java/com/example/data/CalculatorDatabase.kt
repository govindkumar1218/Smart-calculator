package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

// --- entities ---

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val expression: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false,
    val type: String = "basic" // basic, scientific, gst, emi, bmi, percentage
)

@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val key: String,
    val value: String
)

@Entity(tableName = "currency_rates")
data class CurrencyRateEntity(
    @PrimaryKey val code: String,
    val rate: Double,
    val lastUpdated: Long = System.currentTimeMillis()
)

// --- daos ---

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history WHERE expression LIKE :query OR result LIKE :query ORDER BY timestamp DESC")
    fun searchHistory(query: String): Flow<List<HistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(item: HistoryEntity)

    @Query("UPDATE history SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: Int, isFavorite: Boolean)

    @Query("DELETE FROM history WHERE id = :id")
    suspend fun deleteById(id: Int)

    @Query("DELETE FROM history")
    suspend fun clearAll()
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM settings")
    fun getAllSettings(): Flow<List<SettingsEntity>>

    @Query("SELECT * FROM settings WHERE `key` = :key LIMIT 1")
    suspend fun getSettingByKey(key: String): SettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetting(setting: SettingsEntity)
}

@Dao
interface CurrencyRateDao {
    @Query("SELECT * FROM currency_rates")
    fun getRates(): Flow<List<CurrencyRateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRates(rates: List<CurrencyRateEntity>)
}

// --- database ---

@Database(
    entities = [HistoryEntity::class, SettingsEntity::class, CurrencyRateEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao
    abstract fun settingsDao(): SettingsDao
    abstract fun currencyRateDao(): CurrencyRateDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mithlesh_calculator_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

// --- repository ---

class CalculatorRepository(private val db: AppDatabase) {
    val historyDao = db.historyDao()
    val settingsDao = db.settingsDao()
    val currencyRateDao = db.currencyRateDao()

    val allHistory: Flow<List<HistoryEntity>> = historyDao.getAllHistory()

    fun searchHistory(query: String): Flow<List<HistoryEntity>> {
        return historyDao.searchHistory("%$query%")
    }

    suspend fun addHistory(expression: String, result: String, type: String) {
        historyDao.insertHistory(
            HistoryEntity(
                expression = expression,
                result = result,
                type = type
            )
        )
    }

    suspend fun toggleFavorite(id: Int, currentStatus: Boolean) {
        historyDao.updateFavorite(id, !currentStatus)
    }

    suspend fun deleteHistory(id: Int) {
        historyDao.deleteById(id)
    }

    suspend fun clearHistory() {
        historyDao.clearAll()
    }

    // Settings
    val allSettings: Flow<List<SettingsEntity>> = settingsDao.getAllSettings()

    suspend fun getSetting(key: String, defaultValue: String): String {
        return settingsDao.getSettingByKey(key)?.value ?: defaultValue
    }

    suspend fun saveSetting(key: String, value: String) {
        settingsDao.insertSetting(SettingsEntity(key, value))
    }

    // Currency rates
    val cachedRates: Flow<List<CurrencyRateEntity>> = currencyRateDao.getRates()

    suspend fun saveRates(rates: List<CurrencyRateEntity>) {
        currencyRateDao.insertRates(rates)
    }
}
