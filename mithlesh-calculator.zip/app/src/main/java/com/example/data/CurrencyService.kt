package com.example.data

import com.squareup.moshi.Json
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import java.util.concurrent.TimeUnit

data class CurrencyResponse(
    @Json(name = "result") val result: String,
    @Json(name = "base_code") val baseCode: String,
    @Json(name = "rates") val rates: Map<String, Double>
)

interface CurrencyApi {
    @GET("v6/latest/USD")
    suspend fun getLatestRates(): CurrencyResponse
}

object CurrencyClient {
    private const val BASE_URL = "https://open.er-api.com/"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    val api: CurrencyApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(CurrencyApi::class.java)
    }

    // High fidelity default offline rates (relative to USD) to guarantee instant play-store ready offline operation
    val defaultRates = mapOf(
        "USD" to 1.0,
        "INR" to 83.50,
        "EUR" to 0.92,
        "GBP" to 0.78,
        "JPY" to 158.20,
        "AUD" to 1.50,
        "CAD" to 1.37,
        "CNY" to 7.25,
        "SGD" to 1.35,
        "AED" to 3.67,
        "CHF" to 0.89,
        "NZD" to 1.63,
        "ZAR" to 18.15
    )
}
